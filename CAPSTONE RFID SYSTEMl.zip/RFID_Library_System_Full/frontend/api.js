/* =========================================================================
   api.js — data layer. Every page gets its data through window.UEP.
   Each function returns a Promise. When UEP_CONFIG.API_BASE_URL is empty
   the "read" functions resolve with empty data (no dummy values) and the
   "write" functions resolve with null, so pages render clean empty states.
   Endpoint contracts: see DATABASE_CONNECTION.md
   ========================================================================= */
(function(w){
  var cfg = w.UEP_CONFIG || {};
  var base = (cfg.API_BASE_URL || '').replace(/\/+$/, '');
  var KEY = cfg.SESSION_KEY || 'uepStaffSession';

  function getSession(){
    try { return JSON.parse(localStorage.getItem(KEY) || 'null'); } catch(e){ return null; }
  }
  function isConnected(){ return !!base; }

  function request(method, path, body){
    if(!isConnected()) return Promise.reject(new Error('NOT_CONNECTED'));
    var headers = { 'Content-Type':'application/json' };
    var s = getSession();
    if(s && s.token) headers['Authorization'] = 'Bearer ' + s.token;
    return fetch(base + path, { method:method, headers:headers, body: body ? JSON.stringify(body) : undefined })
      .then(function(res){
        if(res.status === 401 && path.indexOf('/auth/') !== 0){
          try { localStorage.removeItem(KEY); } catch(e){}
          location.replace('login.html');
          throw new Error('UNAUTHORIZED');
        }
        if(res.status === 404) return null;
        if(!res.ok) throw new Error('HTTP ' + res.status);
        return res.status === 204 ? null : res.json();
      });
  }
  // read: empty fallback when not connected or on failure (never fake data)
  function read(path, empty){
    if(!isConnected()) return Promise.resolve(empty);
    return request('GET', path).then(function(d){ return d == null ? empty : d; });
  }
  function write(method, path, body){
    if(!isConnected()) return Promise.resolve(null);
    return request(method, path, body);
  }
  function qs(o){
    var p = Object.keys(o || {}).filter(function(k){ return o[k] !== undefined && o[k] !== ''; })
      .map(function(k){ return encodeURIComponent(k) + '=' + encodeURIComponent(o[k]); }).join('&');
    return p ? '?' + p : '';
  }

  var EMPTY_SUMMARY = { total:0, students:0, faculty:0, outsiders:0, female:0, male:0 };

  var UEP = {
    isConnected: isConnected,
    getSession: getSession,

    // ---- auth ----
    login: function(username, password){
      if(!isConnected()) return Promise.resolve(null);
      return fetch(base + '/auth/login', { method:'POST', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify({ username:username, password:password }) })
        .then(function(res){
          if(res.status === 401) return null;            // wrong email/username or password
          if(!res.ok) throw new Error('HTTP ' + res.status); // server / database problem
          return res.json();
        });
    },

    // ---- dashboard / statistics / reports ----
    getDashboard:  function(){ return read('/dashboard', { summary:EMPTY_SUMMARY, recent:[] }); },
    getStatistics: function(f){ return read('/statistics' + qs(f), { summary:EMPTY_SUMMARY, byCollege:[], byYear:[], trend:[] }); },
    getReport:     function(period){ return read('/reports' + qs({ period:period }), { summary:EMPTY_SUMMARY, trend:[], byCollege:[], log:[], rangeLabel:null }); },

    // ---- staff users ----
    getUsers:   function(){ return read('/users', []); },
    saveUser:   function(u){ return u.id ? write('PUT', '/users/' + encodeURIComponent(u.id), u) : write('POST', '/users', u); },
    deleteUser: function(id){ return write('DELETE', '/users/' + encodeURIComponent(id)); },

    // ---- RFID kiosk ----
    getCard:       function(cardId){ return isConnected() ? request('GET', '/cards/' + encodeURIComponent(cardId)) : Promise.resolve(undefined); },
    registerCard:  function(cardId, record){ return write('POST', '/cards', Object.assign({ cardId:cardId }, record)); },
    getInside:     function(){ return read('/visits/inside', []); },
    getTodayVisits:function(){ return read('/visits' + qs({ date:'today' }), []); },
    timeIn:        function(cardId, purpose){ return write('POST', '/visits/time-in',  { cardId:cardId, purpose:purpose }); },
    timeOut:       function(cardId){ return write('POST', '/visits/time-out', { cardId:cardId }); },

    // ---- feedback ----
    getFeedbackToday: function(){ return read('/feedback' + qs({ date:'today' }), null); },
    saveFeedback:     function(entry){ return write('POST', '/feedback', entry); },

    // ---- helpers used by every page ----
    esc: function(v){
      return String(v == null ? '' : v).replace(/[&<>"']/g, function(c){
        return { '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c];
      });
    },
    fmtTime: function(v){
      if(!v) return '—';
      var d = new Date(v); if(isNaN(d)) return String(v);
      return d.toLocaleTimeString('en-US', { hour:'numeric', minute:'2-digit' });
    },
    fmtDate: function(d, opts){ return (d || new Date()).toLocaleDateString('en-US', opts || { weekday:'long', month:'long', day:'numeric', year:'numeric' }); },
    num: function(n){ return Number(n || 0).toLocaleString(); },
    badgeClass: function(type){
      if(type === 'Faculty' || type === 'Staff') return 'faculty';
      if(type === 'Outsider') return 'outsider';
      return 'student';
    },
    // show / hide a "No data yet" message over a chart box
    chartEmpty: function(boxEl, isEmpty, text){
      if(!boxEl) return;
      var n = boxEl.querySelector('.chart-empty');
      if(isEmpty){
        if(!n){ n = document.createElement('div'); n.className = 'chart-empty'; boxEl.appendChild(n); }
        n.textContent = text || 'No data yet';
      } else if(n){ n.remove(); }
    },
    toast: function(msg){
      var t = document.createElement('div'); t.className = 'toast'; t.textContent = msg;
      document.body.appendChild(t); setTimeout(function(){ t.remove(); }, 3500);
    }
  };
  w.UEP = UEP;
})(window);
