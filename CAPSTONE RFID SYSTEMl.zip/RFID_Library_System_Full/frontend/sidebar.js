/* =========================================================================
   sidebar.js — shared behaviour for every page
   - collapse / expand the sidebar (desktop) and persist the choice
   - open / close the sidebar as a drawer on mobile
   - live clock in the topbar
   ========================================================================= */
(function(){
  var shell = document.querySelector('.app-shell');
  var toggleBtn = document.querySelector('[data-action="toggle-sidebar"]');
  var mobileBtn = document.querySelector('[data-action="open-mobile-nav"]');

  if(!shell) return;

  // Safe storage helpers — some browsers (notably Chrome) block localStorage
  // on file:// pages and throw, which would otherwise stop this whole script
  // (and silently break the toggle button below).
  function safeGet(key){
    try { return localStorage.getItem(key); } catch(e){ return null; }
  }
  function safeSet(key, value){
    try { localStorage.setItem(key, value); } catch(e){ /* ignore */ }
  }
  function safeRemove(key){
    try { localStorage.removeItem(key); } catch(e){ /* ignore */ }
  }

  // restore collapsed state
  if(safeGet('uep-sidebar-collapsed') === '1'){
    shell.classList.add('collapsed');
  }

  if(toggleBtn){
    toggleBtn.addEventListener('click', function(){
      shell.classList.toggle('collapsed');
      safeSet('uep-sidebar-collapsed', shell.classList.contains('collapsed') ? '1' : '0');
    });
  }

  var logoutLink = document.getElementById('logoutLink');
  if(logoutLink){
    logoutLink.addEventListener('click', function(e){
      if(!confirm('Sign out of the Visitor Management System?')){
        e.preventDefault();
        return;
      }
      safeRemove('uepStaffSession');
    });
  }

  if(mobileBtn){
    mobileBtn.addEventListener('click', function(){
      shell.classList.toggle('mobile-open');
    });
  }

  // close mobile drawer when a nav link is tapped
  document.querySelectorAll('.nav-item').forEach(function(el){
    el.addEventListener('click', function(){
      shell.classList.remove('mobile-open');
    });
  });

  // ---- profile chip: filled from the signed-in session (no hard-coded name) ----
  function initialsOf(name){
    return String(name || '').split(/\s+/).filter(Boolean).slice(0,2).map(function(w){ return w[0]; }).join('').toUpperCase() || '–';
  }
  var session = (window.UEP && UEP.getSession()) || null;
  var displayName = session ? (session.name || session.user || '') : '';
  function setRole(sel, text){ document.querySelectorAll('[data-role="' + sel + '"]').forEach(function(el){ el.textContent = text; }); }
  setRole('user-name', displayName || 'Staff');
  setRole('user-role', session && session.role ? session.role : '');
  setRole('user-initials', initialsOf(displayName));

  // ---- RFID reader status chip (top bar) ----
  // The reader is a USB "keyboard-style" device, so the browser can't query it directly.
  // The kiosk page (attendance.html) records the time of every card tap; the chip turns
  // green when the reader has sent a tap today and shows when the last tap happened.
  var chip = document.getElementById('connChip');
  if(chip){
    var label = chip.querySelector('.conn-text');
    var RKEY = (window.UEP_CONFIG && UEP_CONFIG.READER_KEY) || 'uepReaderLastTap';
    var RNAME = (window.UEP_CONFIG && UEP_CONFIG.READER_NAME) || 'RFID reader';
    function paintReader(){
      var last = parseInt(safeGet(RKEY) || '0', 10);
      var today = new Date(); today.setHours(0,0,0,0);
      if(last && last >= today.getTime()){
        chip.className = 'conn-chip online';
        label.textContent = RNAME + ' connected \u2022 last tap ' +
          new Date(last).toLocaleTimeString('en-US', { hour:'numeric', minute:'2-digit' });
      } else {
        chip.className = 'conn-chip';
        label.textContent = RNAME + ' not detected';
      }
    }
    paintReader();
    window.addEventListener('storage', function(e){ if(e.key === RKEY) paintReader(); });
    setInterval(paintReader, 30000);
  }
})();
