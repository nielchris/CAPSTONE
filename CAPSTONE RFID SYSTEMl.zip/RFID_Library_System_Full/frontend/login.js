/* =========================================================================
   login.js — sign-in form behaviour (credentials are checked by your backend via UEP.login)
   ========================================================================= */
(function(){
  var form = document.getElementById('loginForm');
  var pwInput = document.getElementById('loginPass');
  var pwToggle = document.getElementById('pwToggle');
  var errorMsg = document.getElementById('loginError');

  if(pwToggle){
    pwToggle.addEventListener('click', function(){
      var showing = pwInput.type === 'text';
      pwInput.type = showing ? 'password' : 'text';
      pwToggle.setAttribute('aria-label', showing ? 'Show password' : 'Hide password');
    });
  }

  if(form){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      var user = document.getElementById('loginUser').value.trim();
      var pass = pwInput.value.trim();
      if(!user || !pass){
        errorMsg.hidden = false;
        return;
      }
      errorMsg.hidden = true;
      var key = (window.UEP_CONFIG && UEP_CONFIG.SESSION_KEY) || 'uepStaffSession';

      function finish(session){
        try { localStorage.setItem(key, JSON.stringify(session)); } catch (e) { /* storage unavailable */ }
        window.location.href = 'dashboard.html';
      }

      if(!UEP.isConnected()){
        // No database yet: let staff into the empty system so the UI can be set up.
        // Once API_BASE_URL is set in config.js this branch is never used.
        finish({ user:user, name:user, since:Date.now() });
        return;
      }
      // Connected: the backend must verify the credentials and return { token, user:{ name, role } }.
      UEP.login(user, pass).then(function(res){
        if(!res || !res.token){ errorMsg.textContent = 'Incorrect email/username or password.'; errorMsg.hidden = false; return; }
        finish({ user:user, name:(res.user && res.user.name) || user, role:(res.user && res.user.role) || '', token:res.token, since:Date.now() });
      }).catch(function(){
        errorMsg.textContent = 'Can\u2019t reach the server or database. Make sure the backend is running (npm start) and the MySQL password in .env is correct.'; errorMsg.hidden = false;
      });
    });
  }
})();
