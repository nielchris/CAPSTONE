-- =====================================================================
--  UEP Library Visitors Management System (RFID)  -  MySQL 8 schema
--  Open in MySQL Workbench -> File > Open SQL Script -> run all (lightning icon)
-- =====================================================================

DROP DATABASE IF EXISTS uep_library;
CREATE DATABASE uep_library CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE uep_library;

-- ---------------------------------------------------------------------
-- 1. STAFF USERS (login + User Management page)
-- ---------------------------------------------------------------------
CREATE TABLE users (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(120) NOT NULL,
  email         VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,                 -- bcrypt hash, never plain text
  role          ENUM('Administrator','Librarian','Library Assistant') NOT NULL DEFAULT 'Librarian',
  status        ENUM('Active','Inactive')         NOT NULL DEFAULT 'Active',
  last_login    DATETIME NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 2. REGISTERED RFID CARDS / VISITOR PROFILES
--    course and year level are separate columns
-- ---------------------------------------------------------------------
CREATE TABLE cards (
  card_id    VARCHAR(50)  NOT NULL PRIMARY KEY,         -- RFID card number / ID number
  name       VARCHAR(120) NOT NULL,
  type       ENUM('Student','Faculty','Staff','Outsider') NOT NULL DEFAULT 'Student',
  college    VARCHAR(100) NOT NULL DEFAULT '—',
  course     VARCHAR(100) NOT NULL DEFAULT '—',
  year_level ENUM('1st Year','2nd Year','3rd Year','4th Year','5th Year','—') NOT NULL DEFAULT '—',
  gender     ENUM('Female','Male','—') NOT NULL DEFAULT '—',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_cards_college (college),
  INDEX idx_cards_year (year_level)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 3. VISITS (time in / time out). time_out IS NULL = still inside
-- ---------------------------------------------------------------------
CREATE TABLE visits (
  id        BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  card_id   VARCHAR(50) NOT NULL,
  purpose   VARCHAR(100) NULL,
  time_in   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  time_out  DATETIME NULL,
  CONSTRAINT fk_visits_card FOREIGN KEY (card_id) REFERENCES cards(card_id)
    ON UPDATE CASCADE ON DELETE CASCADE,
  INDEX idx_visits_time_in (time_in),
  INDEX idx_visits_card (card_id, time_out)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 4. FEEDBACK  (rate: 1 = Bad, 2 = Not So Bad, 3 = Good)
-- ---------------------------------------------------------------------
CREATE TABLE feedback (
  id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  card_id    VARCHAR(50) NOT NULL,
  rate       TINYINT UNSIGNED NOT NULL,
  label      ENUM('Bad','Not So Bad','Good') NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_rate CHECK (rate BETWEEN 1 AND 3),
  CONSTRAINT fk_feedback_card FOREIGN KEY (card_id) REFERENCES cards(card_id)
    ON UPDATE CASCADE ON DELETE CASCADE,
  INDEX idx_feedback_date (created_at)
) ENGINE=InnoDB;

-- =====================================================================
--  VIEWS  (ready-made queries the backend can call)
-- =====================================================================

-- Full visit log (Reports page + Live feed): one row per visit with visitor details
CREATE VIEW v_visit_log AS
SELECT v.id, v.card_id AS id_no, c.name, c.type, c.college, c.course,
       c.year_level AS year, c.gender, v.purpose, v.time_in, v.time_out
FROM visits v
JOIN cards c ON c.card_id = v.card_id;

-- Today's summary cards (Dashboard)
CREATE VIEW v_today_summary AS
SELECT COUNT(*)                                   AS total,
       COALESCE(SUM(type = 'Student'), 0)         AS students,
       COALESCE(SUM(type IN ('Faculty','Staff')), 0) AS faculty,
       COALESCE(SUM(type = 'Outsider'), 0)        AS outsiders,
       COALESCE(SUM(gender = 'Female'), 0)        AS female,
       COALESCE(SUM(gender = 'Male'), 0)          AS male
FROM v_visit_log
WHERE DATE(time_in) = CURDATE();

-- Visitors per day (Statistics trend)
CREATE VIEW v_daily_trend AS
SELECT DATE(time_in) AS day, COUNT(*) AS count
FROM visits GROUP BY DATE(time_in);

-- Visitors per college (Statistics + Reports)
CREATE VIEW v_by_college AS
SELECT DATE(time_in) AS day, college, COUNT(*) AS count,
       SUM(type = 'Student') AS students,
       SUM(type IN ('Faculty','Staff')) AS faculty,
       SUM(type = 'Outsider') AS outsiders,
       SUM(gender = 'Female') AS female,
       SUM(gender = 'Male') AS male
FROM v_visit_log GROUP BY DATE(time_in), college;

-- Visitors per year level (the new year-level chart: most / least)
CREATE VIEW v_by_year AS
SELECT DATE(time_in) AS day, year, COUNT(*) AS count
FROM v_visit_log
WHERE year <> '—'
GROUP BY DATE(time_in), year;

-- Feedback totals per day (Feedback page)
CREATE VIEW v_feedback_daily AS
SELECT DATE(created_at) AS day, label, COUNT(*) AS count
FROM feedback GROUP BY DATE(created_at), label;

-- =====================================================================
--  STARTER DATA
--  Default admin login:  admin@uep.edu.ph   /   Admin@123   (change it!)
-- =====================================================================
INSERT INTO users (name, email, password_hash, role, status) VALUES
('Library Admin', 'admin@uep.edu.ph',
 '$2b$10$dSP5iA3Vlvy9uK6Jdb8zquEVd/TmORZpREVBIJowg0kYMs4aok.le',
 'Administrator', 'Active');

-- Optional sample visitors so you can test the charts (delete if not needed)
INSERT INTO cards (card_id, name, type, college, course, year_level, gender) VALUES
('2022-0001','Juan Dela Cruz','Student','College of Science','BSIT','3rd Year','Male'),
('2023-0002','Maria Santos','Student','College of Education','BSEd','1st Year','Female'),
('2021-0003','Pedro Reyes','Student','College of Engineering','BSCE','4th Year','Male'),
('F-0001','Dr. Ana Lopez','Faculty','College of Science','—','—','Female');

INSERT INTO visits (card_id, purpose, time_in, time_out) VALUES
('2022-0001','Research / Study', NOW() - INTERVAL 3 HOUR, NOW() - INTERVAL 1 HOUR),
('2023-0002','Borrow materials', NOW() - INTERVAL 2 HOUR, NOW() - INTERVAL 1 HOUR),
('2021-0003','Reading area',     NOW() - INTERVAL 1 HOUR, NULL),
('F-0001','Use of computer / internet', NOW() - INTERVAL 30 MINUTE, NULL);

INSERT INTO feedback (card_id, rate, label) VALUES
('2022-0001', 3, 'Good'),
('2023-0002', 2, 'Not So Bad');

-- Quick check after running:
-- SELECT * FROM v_today_summary;
-- SELECT * FROM v_by_year;
