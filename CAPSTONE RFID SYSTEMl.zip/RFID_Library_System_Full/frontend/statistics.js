/* statistics.js — Chart.js visuals for the statistics page.
   Data: UEP.getStatistics({from, to, college}) — see DATABASE_CONNECTION.md */
(function(){
  if(typeof Chart === 'undefined') return;
  Chart.defaults.font.family = "'Plus Jakarta Sans', sans-serif";
  Chart.defaults.color = '#81796B';

  var BLUE='#1B1F8F', GOLD='#D8912F', TEAL='#12837F', GRID='#EFE7D6', EMPTY='#EFE7D6';
  function ctx(id){ return document.getElementById(id); }
  function mk(id, cfg){ var el = ctx(id); return el ? new Chart(el, cfg) : null; }
  var scales = { x:{ grid:{ display:false } }, y:{ grid:{ color:GRID }, beginAtZero:true, ticks:{ precision:0 } } };

  var collegeChart = mk('collegeBar', { type:'bar',
    data:{ labels:[], datasets:[{ data:[], backgroundColor:BLUE, borderRadius:10, maxBarThickness:38 }] },
    options:{ maintainAspectRatio:false, plugins:{ legend:{ display:false } }, scales:scales } });
  var YEARS = ['1st Year','2nd Year','3rd Year','4th Year','5th Year'];
  var YEAR_COLORS = ['#1B1F8F','#12837F','#D8912F','#E58BA0','#7A6FD6'];
  var yearChart = mk('yearBar', { type:'bar',
    data:{ labels:YEARS, datasets:[{ data:[0,0,0,0,0], backgroundColor:YEAR_COLORS, borderRadius:10, maxBarThickness:60 }] },
    options:{ maintainAspectRatio:false, plugins:{ legend:{ display:false } }, scales:scales } });
  var typeChart = mk('typeDonut', { type:'doughnut',
    data:{ labels:['Students','Faculty','Outsiders'], datasets:[{ data:[0,0,0], backgroundColor:[BLUE,TEAL,GOLD], borderWidth:0 }] },
    options:{ cutout:'72%', maintainAspectRatio:false, plugins:{ legend:{ display:false } } } });
  var genderChart = mk('genderDonut2', { type:'doughnut',
    data:{ labels:['Female','Male'], datasets:[{ data:[0,0], backgroundColor:[BLUE,GOLD], borderWidth:0 }] },
    options:{ cutout:'72%', maintainAspectRatio:false, plugins:{ legend:{ display:false } } } });
  var trendChart = mk('trendLine', { type:'line',
    data:{ labels:[], datasets:[{ data:[], borderColor:BLUE, backgroundColor:'rgba(27,31,143,.08)', fill:true, tension:.4, pointRadius:3, pointBackgroundColor:BLUE }] },
    options:{ maintainAspectRatio:false, plugins:{ legend:{ display:false } }, scales:scales } });

  function iso(d){ return d.toISOString().slice(0,10); }
  var fFrom = document.getElementById('fFrom'), fTo = document.getElementById('fTo');
  var today = new Date(), weekAgo = new Date(); weekAgo.setDate(today.getDate() - 6);
  fFrom.value = iso(weekAgo); fTo.value = iso(today);   // default: last 7 days

  function setDonut(chart, data, colors){
    var empty = !data.some(function(n){ return n > 0; });
    chart.data.datasets[0].data = empty ? [1] : data;
    chart.data.datasets[0].backgroundColor = empty ? [EMPTY] : colors;
    chart.update();
  }
  function box(chart){ return chart.canvas.parentNode; }
  function set(id, v){ document.getElementById(id).textContent = UEP.num(v); }

  function load(){
    var college = document.getElementById('fCollege').value;
    UEP.getStatistics({ from:fFrom.value, to:fTo.value, college: /^All/.test(college) ? '' : college }).then(function(d){
      var m = d.summary || {};
      var total = m.total != null ? m.total : (m.students||0)+(m.faculty||0)+(m.outsiders||0);
      set('sTotal', total); set('sStudents', m.students); set('sFaculty', m.faculty); set('sOutsiders', m.outsiders);

      var by = d.byCollege || [];
      collegeChart.data.labels = by.map(function(r){ return r.college; });
      collegeChart.data.datasets[0].data = by.map(function(r){ return r.count; });
      collegeChart.update(); UEP.chartEmpty(box(collegeChart), !by.length);

      // year level: server sends byYear:[{year,count}]
      var yr = d.byYear || [], yc = YEARS.map(function(y){
        var hit = yr.filter(function(r){ return String(r.year).toLowerCase().indexOf(y.charAt(0)) === 0; })[0];
        return hit ? hit.count : 0;
      });
      yearChart.data.datasets[0].data = yc; yearChart.update();
      var ytot = yc.reduce(function(a,b){ return a+b; }, 0);
      UEP.chartEmpty(box(yearChart), !ytot);
      var note = document.getElementById('yearNote');
      if(ytot){
        var mx = Math.max.apply(null, yc), mn = Math.min.apply(null, yc.filter(function(n,i){ return i < 4 || n > 0; }));
        note.innerHTML = 'Most visits: <b>' + YEARS[yc.indexOf(mx)] + '</b> (' + UEP.num(mx) + ') &nbsp;\u2022&nbsp; Fewest visits: <b>' + YEARS[yc.indexOf(mn)] + '</b> (' + UEP.num(mn) + ')';
      } else note.textContent = '';

      setDonut(typeChart, [m.students||0, m.faculty||0, m.outsiders||0], [BLUE,TEAL,GOLD]);
      UEP.chartEmpty(box(typeChart), !total);
      setDonut(genderChart, [m.female||0, m.male||0], [BLUE,GOLD]);
      UEP.chartEmpty(box(genderChart), !(m.female||m.male));

      var tr = d.trend || [];
      trendChart.data.labels = tr.map(function(r){ return r.label; });
      trendChart.data.datasets[0].data = tr.map(function(r){ return r.count; });
      trendChart.update(); UEP.chartEmpty(box(trendChart), !tr.length);
    }).catch(function(){ UEP.toast('Couldn\u2019t load statistics.'); });
  }
  document.getElementById('applyFilters').addEventListener('click', load);
  load();
})();
