/* dashboard.js — greeting, KPI cards, live feed and gender donut.
   All numbers come from UEP.getDashboard() (see api.js / DATABASE_CONNECTION.md). */
(function(){
  var now = new Date();
  var h = now.getHours();
  var part = h < 12 ? 'Good morning' : (h < 18 ? 'Good afternoon' : 'Good evening');
  var s = UEP.getSession();
  var first = s ? String(s.name || s.user || '').split(/[\s@]/)[0] : '';
  document.getElementById('greeting').textContent = part + (first ? ', ' + first : '');
  document.getElementById('heroDate').textContent = UEP.fmtDate(now, { weekday:'long', month:'long', day:'numeric' }) + ' \u2022 Here\u2019s today\u2019s library snapshot.';
  document.getElementById('heroTag').textContent = (window.UEP_CONFIG && UEP_CONFIG.ORG_NAME) || 'University Library';

  var chart = null;
  var el = document.getElementById('genderDonut');
  if(el && typeof Chart !== 'undefined'){
    chart = new Chart(el, {
      type:'doughnut',
      data:{ labels:['Female','Male'], datasets:[{ data:[0,0], backgroundColor:['#1B1F8F','#D8912F'], borderWidth:0, hoverOffset:4 }] },
      options:{ cutout:'74%', plugins:{ legend:{ display:false } }, maintainAspectRatio:false }
    });
  }

  function set(id, v){ document.getElementById(id).textContent = UEP.num(v); }

  UEP.getDashboard().then(function(d){
    var m = d.summary || {};
    var total = m.total != null ? m.total : (m.students || 0) + (m.faculty || 0) + (m.outsiders || 0);
    set('kTotal', total); set('kStudents', m.students); set('kFaculty', m.faculty); set('kOutsiders', m.outsiders);
    set('donutTotal', (m.female || 0) + (m.male || 0));
    set('lgFemale', m.female); set('lgMale', m.male);
    document.getElementById('genderSub').textContent = 'Of ' + UEP.num((m.female || 0) + (m.male || 0)) + ' visitors';
    if(chart){
      var empty = !(m.female || m.male);
      chart.data.datasets[0].data = empty ? [1] : [m.female || 0, m.male || 0];
      chart.data.datasets[0].backgroundColor = empty ? ['#E6DCC8'] : ['#1B1F8F','#D8912F'];
      chart.update();
    }
    var rows = d.recent || [];
    if(rows.length){
      document.getElementById('feedBody').innerHTML = rows.map(function(v){
        return '<tr><td>' + UEP.fmtTime(v.timeIn) + '</td>' +
          '<td class="cell-name">' + UEP.esc(v.name) + '</td>' +
          '<td class="cell-mono">' + UEP.esc(v.id) + '</td>' +
          '<td>' + UEP.esc(v.college || '—') + '</td>' +
          '<td><span class="badge ' + UEP.badgeClass(v.type) + '">' + UEP.esc(v.type) + '</span></td></tr>';
      }).join('');
    }
  }).catch(function(){ UEP.toast('Couldn\u2019t load dashboard data.'); });
})();
