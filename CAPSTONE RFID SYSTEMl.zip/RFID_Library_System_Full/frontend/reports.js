/* =========================================================================
   reports.js — daily / weekly / monthly / yearly reporting view
   Data: UEP.getReport(period) — see DATABASE_CONNECTION.md
   ========================================================================= */
(function(){
  var tabs = document.querySelectorAll('.period-tab');
  var chart = null;
  var currentLog = [];
  var COLS = ['Time In','Time Out','Name','ID No.','College / Department','Course','Year Level','Type','Gender','Purpose'];

  // Fallback range labels, used when the backend doesn't send its own "rangeLabel".
  function fallbackLabel(p){
    var n = new Date(), o = { month:'short', day:'numeric' };
    if(p === 'daily')   return 'Today \u2022 ' + UEP.fmtDate(n, { month:'long', day:'numeric', year:'numeric' });
    if(p === 'weekly'){ var s = new Date(n); s.setDate(n.getDate() - 6); return 'Week of ' + s.toLocaleDateString('en-US', o) + ' \u2013 ' + n.toLocaleDateString('en-US', o) + ', ' + n.getFullYear(); }
    if(p === 'monthly') return n.toLocaleDateString('en-US', { month:'long', year:'numeric' });
    var y = n.getMonth() >= 5 ? n.getFullYear() : n.getFullYear() - 1;
    return 'A.Y. ' + y + ' \u2013 ' + (y + 1);
  }
  var TITLES = { daily:'Footfall \u2014 today', weekly:'Footfall \u2014 this week', monthly:'Footfall \u2014 this month', yearly:'Footfall \u2014 school year' };

  function set(id, v){ document.getElementById(id).textContent = UEP.num(v); }

  function render(period){
    UEP.getReport(period).then(function(d){
      var m = d.summary || {};
      var rows = d.byCollege || [];
      var total = m.total != null ? m.total : (m.students||0)+(m.faculty||0)+(m.outsiders||0);
      var label = d.rangeLabel || fallbackLabel(period);

      document.getElementById('reportRangeLabel').textContent = label;
      document.getElementById('trendTitle').textContent = TITLES[period];
      document.getElementById('tableSubtitle').textContent = label;

      set('sumTotal', total); set('sumStudents', m.students); set('sumFaculty', m.faculty); set('sumOutsiders', m.outsiders);
      set('bdFemale', m.female); set('bdMale', m.male);
      set('bdStudents', m.students); set('bdFaculty', m.faculty); set('bdOutsiders', m.outsiders);

      document.getElementById('reportTableBody').innerHTML = rows.length ? rows.map(function(r){
        var t = (r.students||0) + (r.faculty||0) + (r.outsiders||0);
        return '<tr><td class="cell-name">' + UEP.esc(r.college) + '</td>' +
          '<td>' + UEP.num(r.students) + '</td><td>' + UEP.num(r.faculty) + '</td><td>' + UEP.num(r.outsiders) + '</td>' +
          '<td>' + UEP.num(r.female) + '</td><td>' + UEP.num(r.male) + '</td><td class="cell-mono">' + UEP.num(t) + '</td></tr>';
      }).join('') : '<tr class="table-empty"><td colspan="7">No visits recorded for this period.</td></tr>';

      var tr = d.trend || [];
      var el = document.getElementById('periodChart');
      if(chart) chart.destroy();
      if(el && typeof Chart !== 'undefined'){
        Chart.defaults.font.family = "'Plus Jakarta Sans', sans-serif";
        Chart.defaults.color = '#81796B';
        chart = new Chart(el, { type:'bar',
          data:{ labels:tr.map(function(r){ return r.label; }), datasets:[{ data:tr.map(function(r){ return r.count; }), backgroundColor:'#1B1F8F', borderRadius:10, maxBarThickness:44 }] },
          options:{ maintainAspectRatio:false, plugins:{ legend:{ display:false } }, scales:{ x:{ grid:{ display:false } }, y:{ grid:{ color:'#EFE7D6' }, beginAtZero:true, ticks:{ precision:0 } } } } });
      }
      if(el) UEP.chartEmpty(el.parentNode, !tr.length);

      currentLog = d.log || [];
      renderVisitorLog();
    }).catch(function(){ UEP.toast('Couldn\u2019t load this report.'); });
  }

  function renderVisitorLog(){
    var tbody = document.getElementById('visitorLogTableBody');
    if(!currentLog.length){
      tbody.innerHTML = '<tr class="table-empty"><td colspan="10">No visits recorded for this period.</td></tr>';
      return;
    }
    tbody.innerHTML = currentLog.map(function(v){
      return '<tr>' +
        '<td class="cell-mono">' + UEP.fmtTime(v.timeIn) + '</td>' +
        '<td class="cell-mono">' + UEP.fmtTime(v.timeOut) + '</td>' +
        '<td class="cell-name">' + UEP.esc(v.name) + '</td>' +
        '<td class="cell-mono">' + UEP.esc(v.id) + '</td>' +
        '<td>' + UEP.esc(v.college || '—') + '</td>' +
        '<td>' + UEP.esc(v.course || '—') + '</td>' +
        '<td>' + UEP.esc(v.year || '—') + '</td>' +
        '<td><span class="badge ' + UEP.badgeClass(v.type) + '">' + UEP.esc(v.type) + '</span></td>' +
        '<td>' + UEP.esc(v.gender || '—') + '</td>' +
        '<td>' + UEP.esc(v.purpose || '—') + '</td></tr>';
    }).join('');
  }

  tabs.forEach(function(tab){
    tab.addEventListener('click', function(){
      tabs.forEach(function(t){ t.classList.remove('active'); });
      tab.classList.add('active');
      render(tab.getAttribute('data-period'));
    });
  });

  var printBtn = document.getElementById('printReportBtn');
  if(printBtn){ printBtn.addEventListener('click', function(){ window.print(); }); }

  function csvEscape(value){
    value = String(value == null ? '' : value);
    return /[",\n]/.test(value) ? '"' + value.replace(/"/g, '""') + '"' : value;
  }
  var exportBtn = document.getElementById('exportCsvBtn');
  if(exportBtn){
    exportBtn.addEventListener('click', function(){
      if(!currentLog.length){ UEP.toast('Nothing to export for this period.'); return; }
      // Individual visitor records (name, college, course, time in/out) — not just totals.
      var rows = [COLS].concat(currentLog.map(function(v){
        return [UEP.fmtTime(v.timeIn), UEP.fmtTime(v.timeOut), v.name, v.id, v.college, v.course, v.year, v.type, v.gender, v.purpose];
      }));
      var csv = rows.map(function(r){ return r.map(csvEscape).join(','); }).join('\n');
      var link = document.createElement('a');
      link.href = URL.createObjectURL(new Blob([csv], { type:'text/csv' }));
      var active = document.querySelector('.period-tab.active');
      link.download = 'library-visitor-log-' + (active ? active.getAttribute('data-period') : 'daily') + '.csv';
      link.click();
    });
  }

  render('daily');
})();
