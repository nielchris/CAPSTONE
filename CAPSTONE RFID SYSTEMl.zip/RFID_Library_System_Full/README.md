# UEP Library Visitors Management System

Folders: `frontend/` (the website) and `backend/` (Node.js API).

1. Run `uep_library_database.sql` in MySQL Workbench.
2. In `backend/`: copy `.env.example` to `.env`, put your MySQL password, then `npm install` and `npm start`.
3. Open http://localhost:3000  ->  login: admin@uep.edu.ph / Admin@123
