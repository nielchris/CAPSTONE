/* =========================================================================
   UEP Library Visitors Management System - backend (Node.js + Express + MySQL)
   Implements every endpoint listed in DATABASE_CONNECTION.md
   Run:  npm install   then   npm start
   ========================================================================= */
require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const mysql = require('mysql2/promise');

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'uep_library',
  timezone: process.env.DB_TIMEZONE || '+08:00',
  charset: 'utf8mb4',
  waitForConnections: true,
  connectionLimit: 10
});

const app = express();
app.use(cors());
app.use(express.json());

// ---------------------------------------------------------------- helpers
const q = async (sql, params) => (await pool.query(sql, params))[0];
const wrap = fn => (req, res) => fn(req, res).catch(err => {
  console.error(err);
  res.status(500).json({ error: 'Server error' });
});
const iso = d => (d ? new Date(d).toISOString() : null);
const pad = n => String(n).padStart(2, '0');
const ymd = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const DAYS = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

function visitOut(r) {
  return {
    id: r.id_no, name: r.name, type: r.type, college: r.college, course: r.course,
    year: r.year, gender: r.gender, purpose: r.purpose,
    timeIn: iso(r.time_in), timeOut: iso(r.time_out)
  };
}
function lastLoginText(d) {
  if (!d) return 'Never';
  return new Date(d).toLocaleString('en-US', {
    timeZone: 'Asia/Manila', month: 'short', day: 'numeric', year: 'numeric',
    hour: 'numeric', minute: '2-digit'
  });
}
function userOut(u) {
  return { id: u.id, name: u.name, email: u.email, role: u.role, status: u.status, lastLogin: lastLoginText(u.last_login) };
}

// summary + per-college rows for a WHERE clause on v_visit_log
async function summaryFor(where, params) {
  const [s] = await q(
    `SELECT COUNT(*) total,
            COALESCE(SUM(type='Student'),0) students,
            COALESCE(SUM(type IN ('Faculty','Staff')),0) faculty,
            COALESCE(SUM(type='Outsider'),0) outsiders,
            COALESCE(SUM(gender='Female'),0) female,
            COALESCE(SUM(gender='Male'),0) male
     FROM v_visit_log WHERE ${where}`, params);
  const out = {};
  Object.keys(s).forEach(k => (out[k] = Number(s[k])));
  return out;
}
async function byCollegeFor(where, params) {
  const rows = await q(
    `SELECT college,
            SUM(type='Student') students, SUM(type IN ('Faculty','Staff')) faculty,
            SUM(type='Outsider') outsiders, SUM(gender='Female') female, SUM(gender='Male') male,
            COUNT(*) count
     FROM v_visit_log WHERE ${where} GROUP BY college ORDER BY count DESC`, params);
  return rows.map(r => ({
    college: r.college, count: Number(r.count),
    students: Number(r.students), faculty: Number(r.faculty), outsiders: Number(r.outsiders),
    female: Number(r.female), male: Number(r.male)
  }));
}
async function byYearFor(where, params) {
  const rows = await q(
    `SELECT year, COUNT(*) count FROM v_visit_log WHERE ${where} AND year <> '—' GROUP BY year ORDER BY year`, params);
  return rows.map(r => ({ year: r.year, count: Number(r.count) }));
}
// per-day trend with empty days filled in
async function dailyTrend(from, to, extraWhere, extraParams) {
  const rows = await q(
    `SELECT DATE_FORMAT(time_in,'%Y-%m-%d') d, COUNT(*) c FROM v_visit_log
     WHERE time_in >= ? AND time_in < ? ${extraWhere || ''} GROUP BY d`,
    [from, ymd(addDays(new Date(to), 1)), ...(extraParams || [])]);
  const map = {}; rows.forEach(r => (map[r.d] = Number(r.c)));
  const out = [];
  for (let d = new Date(from); ymd(d) <= to; d = addDays(d, 1)) {
    out.push({ label: MONTHS[d.getMonth()] + ' ' + d.getDate(), count: map[ymd(d)] || 0 });
  }
  return out;
}

// ---------------------------------------------------------------- auth
app.post('/api/auth/login', wrap(async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(401).json({ error: 'Invalid credentials' });
  const [u] = await q(
    `SELECT * FROM users WHERE (email = ? OR SUBSTRING_INDEX(email,'@',1) = ?) AND status = 'Active' LIMIT 1`,
    [username, username]);
  if (!u || !(await bcrypt.compare(password, u.password_hash))) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  await q('UPDATE users SET last_login = ? WHERE id = ?', [new Date(), u.id]);
  const token = jwt.sign({ id: u.id, name: u.name, role: u.role }, JWT_SECRET, { expiresIn: '12h' });
  res.json({ token, user: { name: u.name, role: u.role } });
}));

function auth(req, res, next) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch (e) { res.status(401).json({ error: 'Unauthorized' }); }
}
function adminOnly(req, res, next) {
  if (req.user.role !== 'Administrator') return res.status(403).json({ error: 'Administrators only' });
  next();
}
app.use('/api', auth);

// ---------------------------------------------------------------- dashboard
app.get('/api/dashboard', wrap(async (req, res) => {
  const summary = await summaryFor('DATE(time_in) = CURDATE()', []);
  const recent = await q('SELECT * FROM v_visit_log WHERE DATE(time_in) = CURDATE() ORDER BY time_in DESC LIMIT 5');
  res.json({ summary, recent: recent.map(visitOut) });
}));

// ---------------------------------------------------------------- statistics
app.get('/api/statistics', wrap(async (req, res) => {
  const today = ymd(new Date());
  const from = req.query.from || ymd(addDays(new Date(), -6));
  const to = req.query.to || today;
  const college = req.query.college || '';
  let where = 'time_in >= ? AND time_in < ?';
  const params = [from, ymd(addDays(new Date(to), 1))];
  if (college) { where += ' AND college = ?'; params.push(college); }
  res.json({
    summary: await summaryFor(where, params),
    byCollege: (await byCollegeFor(where, params)).map(r => ({ college: r.college, count: r.count })),
    byYear: await byYearFor(where, params),
    trend: await dailyTrend(from, to, college ? ' AND college = ?' : '', college ? [college] : [])
  });
}));

// ---------------------------------------------------------------- reports
app.get('/api/reports', wrap(async (req, res) => {
  const period = ['daily', 'weekly', 'monthly', 'yearly'].includes(req.query.period) ? req.query.period : 'daily';
  const now = new Date();
  let start, end; // end is exclusive
  if (period === 'daily') { start = new Date(now); end = addDays(now, 1); }
  else if (period === 'weekly') { start = addDays(now, -6); end = addDays(now, 1); }
  else if (period === 'monthly') { start = new Date(now.getFullYear(), now.getMonth(), 1); end = new Date(now.getFullYear(), now.getMonth() + 1, 1); }
  else {
    const y = now.getMonth() >= 5 ? now.getFullYear() : now.getFullYear() - 1; // school year starts June
    start = new Date(y, 5, 1); end = new Date(y + 1, 5, 1);
  }
  const where = 'time_in >= ? AND time_in < ?';
  const params = [ymd(start), ymd(end)];

  let trend = [];
  if (period === 'daily') {
    const rows = await q(`SELECT HOUR(time_in) h, COUNT(*) c FROM v_visit_log WHERE ${where} GROUP BY h`, params);
    const map = {}; rows.forEach(r => (map[r.h] = Number(r.c)));
    for (let h = 6; h <= 20; h++) trend.push({ label: (h % 12 || 12) + (h < 12 ? ' AM' : ' PM'), count: map[h] || 0 });
  } else if (period === 'yearly') {
    const rows = await q(`SELECT YEAR(time_in) y, MONTH(time_in) m, COUNT(*) c FROM v_visit_log WHERE ${where} GROUP BY y, m`, params);
    const map = {}; rows.forEach(r => (map[r.y + '-' + r.m] = Number(r.c)));
    for (let i = 0; i < 12; i++) {
      const d = new Date(start.getFullYear(), 5 + i, 1);
      trend.push({ label: MONTHS[d.getMonth()], count: map[d.getFullYear() + '-' + (d.getMonth() + 1)] || 0 });
    }
  } else {
    const last = ymd(addDays(end, -1));
    trend = await dailyTrend(ymd(start), last);
    if (period === 'weekly') trend.forEach((t, i) => (t.label = DAYS[addDays(start, i).getDay()] + ' ' + addDays(start, i).getDate()));
    if (period === 'monthly') trend.forEach((t, i) => (t.label = String(i + 1)));
  }

  const log = await q(`SELECT * FROM v_visit_log WHERE ${where} ORDER BY time_in DESC LIMIT 5000`, params);
  res.json({
    rangeLabel: null,
    summary: await summaryFor(where, params),
    trend,
    byCollege: await byCollegeFor(where, params),
    log: log.map(visitOut)
  });
}));

// ---------------------------------------------------------------- users (admin only)
app.get('/api/users', adminOnly, wrap(async (req, res) => {
  res.json((await q('SELECT * FROM users ORDER BY id')).map(userOut));
}));
app.post('/api/users', adminOnly, wrap(async (req, res) => {
  const { name, email, role, status, password } = req.body || {};
  if (!name || !email || !password) return res.status(400).json({ error: 'name, email and password are required' });
  try {
    const hash = await bcrypt.hash(password, 10);
    const r = await q('INSERT INTO users (name, email, password_hash, role, status) VALUES (?,?,?,?,?)',
      [name, email, hash, role || 'Librarian', status || 'Active']);
    const [u] = await q('SELECT * FROM users WHERE id = ?', [r.insertId]);
    res.status(201).json(userOut(u));
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Email already exists' });
    throw e;
  }
}));
app.put('/api/users/:id', adminOnly, wrap(async (req, res) => {
  const { name, email, role, status, password } = req.body || {};
  const [old] = await q('SELECT * FROM users WHERE id = ?', [req.params.id]);
  if (!old) return res.status(404).end();
  await q('UPDATE users SET name=?, email=?, role=?, status=? WHERE id=?',
    [name || old.name, email || old.email, role || old.role, status || old.status, old.id]);
  if (password) await q('UPDATE users SET password_hash=? WHERE id=?', [await bcrypt.hash(password, 10), old.id]);
  const [u] = await q('SELECT * FROM users WHERE id = ?', [old.id]);
  res.json(userOut(u));
}));
app.delete('/api/users/:id', adminOnly, wrap(async (req, res) => {
  if (String(req.user.id) === String(req.params.id)) return res.status(400).json({ error: "You can't delete your own account" });
  await q('DELETE FROM users WHERE id = ?', [req.params.id]);
  res.status(204).end();
}));

// ---------------------------------------------------------------- cards
app.get('/api/cards/:cardId', wrap(async (req, res) => {
  const [c] = await q('SELECT * FROM cards WHERE card_id = ?', [req.params.cardId]);
  if (!c) return res.status(404).end();
  res.json({ name: c.name, type: c.type, college: c.college, course: c.course, year: c.year_level, gender: c.gender });
}));
app.post('/api/cards', wrap(async (req, res) => {
  const b = req.body || {};
  if (!b.cardId || !b.name) return res.status(400).json({ error: 'cardId and name are required' });
  await q(
    `INSERT INTO cards (card_id, name, type, college, course, year_level, gender) VALUES (?,?,?,?,?,?,?)
     ON DUPLICATE KEY UPDATE name=VALUES(name), type=VALUES(type), college=VALUES(college),
       course=VALUES(course), year_level=VALUES(year_level), gender=VALUES(gender)`,
    [b.cardId, b.name, b.type || 'Student', b.college || '—', b.course || '—', b.year || '—', b.gender || '—']);
  res.status(201).json({ ok: true });
}));

// ---------------------------------------------------------------- visits
app.get('/api/visits', wrap(async (req, res) => {
  const rows = await q('SELECT * FROM v_visit_log WHERE DATE(time_in) = CURDATE() ORDER BY time_in DESC');
  res.json(rows.map(visitOut));
}));
app.get('/api/visits/inside', wrap(async (req, res) => {
  const rows = await q('SELECT * FROM v_visit_log WHERE time_out IS NULL ORDER BY time_in DESC');
  res.json(rows.map(visitOut));
}));
app.post('/api/visits/time-in', wrap(async (req, res) => {
  const { cardId, purpose } = req.body || {};
  const [c] = await q('SELECT card_id FROM cards WHERE card_id = ?', [cardId]);
  if (!c) return res.status(404).json({ error: 'Card not registered' });
  const [open] = await q('SELECT id FROM visits WHERE card_id = ? AND time_out IS NULL LIMIT 1', [cardId]);
  if (open) return res.status(200).json({ ok: true, alreadyInside: true });
  await q('INSERT INTO visits (card_id, purpose, time_in) VALUES (?,?,?)', [cardId, purpose || null, new Date()]);
  res.status(201).json({ ok: true });
}));
app.post('/api/visits/time-out', wrap(async (req, res) => {
  const { cardId } = req.body || {};
  const r = await q('UPDATE visits SET time_out = ? WHERE card_id = ? AND time_out IS NULL', [new Date(), cardId]);
  if (!r.affectedRows) return res.status(404).end();
  res.json({ ok: true });
}));

// ---------------------------------------------------------------- feedback (1 Bad, 2 Not So Bad, 3 Good)
const LABELS = { 1: 'Bad', 2: 'Not So Bad', 3: 'Good' };
app.get('/api/feedback', wrap(async (req, res) => {
  const rows = await q(
    `SELECT f.id, f.card_id, c.name, c.type, f.rate, f.label, f.created_at
     FROM feedback f JOIN cards c ON c.card_id = f.card_id
     WHERE DATE(f.created_at) = CURDATE() ORDER BY f.created_at DESC`);
  res.json(rows.map(r => ({ id: r.card_id, name: r.name, type: r.type, rate: r.rate, label: r.label, time: iso(r.created_at) })));
}));
app.post('/api/feedback', wrap(async (req, res) => {
  const { id, rate } = req.body || {};
  if (!LABELS[rate]) return res.status(400).json({ error: 'rate must be 1, 2 or 3' });
  const [c] = await q('SELECT card_id FROM cards WHERE card_id = ?', [id]);
  if (!c) return res.status(404).json({ error: 'Card not registered' });
  await q('INSERT INTO feedback (card_id, rate, label, created_at) VALUES (?,?,?,?)', [id, rate, LABELS[rate], new Date()]);
  res.status(201).json({ ok: true });
}));

app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));

// ---------------------------------------------------------------- serve the website too
app.use(express.static(path.join(__dirname, '..', 'frontend')));

app.listen(PORT, () => {
  console.log('UEP Library system running:  http://localhost:' + PORT);
});
