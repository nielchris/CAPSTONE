Put your library photo here and name it:  library.jpg
(landscape, at least 1600 x 1000 px). It fills the left side of the login page.
