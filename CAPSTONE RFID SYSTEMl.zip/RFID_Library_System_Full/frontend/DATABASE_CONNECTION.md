# Connecting the system to your database

The browser never talks to the database directly. Your backend (Node, PHP, Python, etc.)
sits between them and exposes the JSON endpoints below.

**To connect:** open `config.js` and set `API_BASE_URL` (e.g. `'http://localhost:3000/api'`).
The "Database not connected" label in the top bar turns green once the backend responds.
All requests send `Authorization: Bearer <token>` (the token returned by `/auth/login`).
A `401` response sends the user back to the sign-in page. Return `404` when a record is not found.

Timestamps are ISO 8601 strings (e.g. `2026-11-06T09:14:00+08:00`). The pages format them for display.

## Shared shapes
**Visit**
`{ id, name, type, college, course, year, gender, purpose, timeIn, timeOut }`
(`id` = card / ID number, `type` = Student | Faculty | Staff | Outsider, `timeOut` = null while inside)

**Summary**
`{ total, students, faculty, outsiders, female, male }`

## Endpoints
| Method & path | Returns / body |
|---|---|
| `POST /auth/login` `{username,password}` | `{ token, user:{ name, role } }` (401 or no token = wrong credentials) |
| `GET /dashboard` | `{ summary: Summary (today), recent: [Visit] (latest 5 today) }` |
| `GET /statistics?from=YYYY-MM-DD&to=YYYY-MM-DD&college=` | `{ summary, byCollege:[{college,count}], trend:[{label,count}] }` |
| `GET /reports?period=daily\|weekly\|monthly\|yearly` | `{ rangeLabel?, summary, trend:[{label,count}], byCollege:[{college,students,faculty,outsiders,female,male}], log:[Visit] }` |
| `GET /users` | `[{ id, name, email, role, status, lastLogin }]` |
| `POST /users` / `PUT /users/:id` | body: user fields (`password` on create). Returns the saved user with `id` |
| `DELETE /users/:id` | 204 |
| `GET /cards/:cardId` | `{ name, type, college, course, year, gender }` or 404 if unregistered |
| `POST /cards` | `{ cardId, name, type, college, course, year, gender }` |
| `GET /visits?date=today` | `[Visit]` (today's log, including people still inside) |
| `GET /visits/inside` | `[Visit]` (currently inside) |
| `POST /visits/time-in` `{cardId,purpose}` | 201 |
| `POST /visits/time-out` `{cardId}` | 200 |
| `GET /feedback?date=today` | `[{ id, name, type, rate, label, time }]` (`rate`: 1 Bad, 2 Not So Bad, 3 Good) |
| `POST /feedback` | `{ id, name, type, rate, label, time }` |

## Suggested tables
```sql
users(id, name, email UNIQUE, password_hash, role, status, last_login)
cards(card_id PRIMARY KEY, name, type, college, course, year, gender)
visits(id, card_id, purpose, time_in, time_out)
feedback(id, card_id, rate, label, created_at)
```
Hash passwords (bcrypt/argon2) and check the token on every endpoint. The front-end sign-in
gate only hides pages; it does not protect your data.

## Where the code lives
- `config.js` – the backend address (only file you must edit)
- `api.js` – every call the pages make; change a path here if your routes differ
- Until `API_BASE_URL` is set, every page shows empty states and the kiosk keeps a temporary
  in-memory log that is cleared on refresh. Sign-in accepts any entry while disconnected.

## RFID reader status (top bar)
The top bar now shows the RFID reader instead of the database. USB readers act like a keyboard, so the
system marks the reader "connected" when a card tap is received on the kiosk (attendance.html) and shows
the time of the last tap. Set the label in `config.js` → `READER_NAME`.


## Year-level chart
`GET /statistics` should also return `byYear:[{year:"1st Year",count:12}, ...]` (years 1st–5th). Course and year are now saved as separate fields (`course`, `year`).
