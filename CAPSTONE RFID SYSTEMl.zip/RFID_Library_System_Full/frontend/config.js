/* =========================================================================
   config.js — the ONLY file you need to edit to connect your database.
   -------------------------------------------------------------------------
   Set API_BASE_URL to the address of your backend (the server that talks to
   your database), e.g.  'http://localhost:3000/api'  or  '/api'.

   While API_BASE_URL is empty the system runs "disconnected": every page
   shows empty states (zeros / "No data yet") and the RFID kiosk keeps a
   temporary in-memory log that is lost on refresh.
   See DATABASE_CONNECTION.md for the endpoints your backend must provide.
   ========================================================================= */
window.UEP_CONFIG = {
  API_BASE_URL: 'http://localhost:3000/api',
  ORG_NAME: 'University Library',
  READER_NAME: 'RFID reader',   // shown in the top bar, e.g. 'Entrance reader'
  READER_KEY: 'uepReaderLastTap',
  SESSION_KEY: 'uepStaffSession'
};
